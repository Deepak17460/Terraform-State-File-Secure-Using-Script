import base64
import hashlib

# Read the contents of your Terraform state file
with open('terraform.tfstate', 'rb') as f:
    file_contents = f.read()

# Compute the SHA-256 hash
sha256_hash = hashlib.sha256(file_contents).digest()

# Encode the hash in Base64
encoded_hash = base64.b64encode(sha256_hash).decode('utf-8')

print(encoded_hash)
