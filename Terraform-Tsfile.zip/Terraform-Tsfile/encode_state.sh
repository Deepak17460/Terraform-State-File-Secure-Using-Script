#!/bin/bash
# Step 1: Run Terraform Apply
terraform apply
# Check if Terraform apply was successful
if [ $? -eq 0 ]; then
    # Step 2: Encode the State File
    ENCODED_STATE=$(python3 encode_state.py)
    echo $ENCODED_STATE > terraform.tfstate
    echo "State file encoded and replaced successfully."
else
    echo "Terraform apply failed. State file not encoded."
fi
